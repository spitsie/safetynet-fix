# Inter Font Pack

An Android font pack with:

- Inter for general text
- San Francisco UI Text for condensed
- JetBrains Mono for monospace
- Source Serif Pro for serif
